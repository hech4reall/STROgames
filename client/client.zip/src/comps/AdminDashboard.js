"use client"

import { useEffect, useState } from "react"
import { useSelector, useDispatch } from "react-redux"
import {
  getAllBookings,
  approveBooking,
  rejectBooking,
  deleteBooking,
  clearBusError,
  clearBusSuccess,
} from "../redux/slices/busSlice" // Corrected path
import { getAllOffers, deleteOffer, clearOfferError, clearOfferSuccess } from "../redux/slices/offerSlice" // Corrected path
import "./AdminDashboard.css"

const AdminDashboard = () => {
  const dispatch = useDispatch()
  const { user } = useSelector((state) => state.auth)
  const {
    bookings,
    loading: busLoading,
    error: busError,
    successMessage: busSuccess,
  } = useSelector((state) => state.bus)
  const {
    offers,
    loading: offerLoading,
    error: offerError,
    successMessage: offerSuccess,
  } = useSelector((state) => state.offer)

  // State for managing price input for each booking
  const [bookingPrices, setBookingPrices] = useState({})

  useEffect(() => {
    if (user && user.role === "admin") {
      dispatch(getAllBookings())
      dispatch(getAllOffers())
    }
    return () => {
      // Clear messages and errors on component unmount
      dispatch(clearBusError())
      dispatch(clearBusSuccess())
      dispatch(clearOfferError())
      dispatch(clearOfferSuccess())
    }
  }, [user, dispatch])

  const handlePriceChange = (bookingId, price) => {
    setBookingPrices((prev) => ({ ...prev, [bookingId]: price }))
  }

  const handleApproveBooking = (bookingId) => {
    const price = bookingPrices[bookingId]
    if (!price || isNaN(Number.parseFloat(price)) || Number.parseFloat(price) <= 0) {
      alert("Veuillez entrer un prix valide pour l'approbation.")
      return
    }
    dispatch(approveBooking({ bookingId, prix: Number.parseFloat(price) }))
  }

  const handleRejectBooking = (bookingId) => {
    dispatch(rejectBooking(bookingId))
  }

  const handleDeleteBooking = (bookingId) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cette réservation ?")) {
      dispatch(deleteBooking(bookingId))
    }
  }

  const handleDeleteOffer = (offerId) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cette offre ?")) {
      dispatch(deleteOffer(offerId))
    }
  }

  if (!user || user.role !== "admin") {
    return <div className="unauthorized-message">Vous n'êtes pas autorisé à voir cette page.</div>
  }

  if (busLoading || offerLoading) {
    return <div className="loading-message">Chargement des données du tableau de bord...</div>
  }

  return (
    <div className="admin-dashboard-container">
      <header className="dashboard-header">
        <h1>Tableau de Bord Administrateur</h1>
      </header>

      {busError && <div className="error-message admin-error">Erreur Réservations: {busError}</div>}
      {busSuccess && <div className="success-message admin-success">Action Réservations: {busSuccess}</div>}
      {offerError && <div className="error-message admin-error">Erreur Offres: {offerError}</div>}
      {offerSuccess && <div className="success-message admin-success">Action Offres: {offerSuccess}</div>}

      <section className="dashboard-section">
        <h3>Toutes les Locations de Bus (Réservations)</h3>
        {bookings.length === 0 ? (
          <p className="empty-state">Aucune location de bus trouvée.</p>
        ) : (
          <div className="table-responsive">
            <table className="dashboard-table">
              <thead>
                <tr>
                  <th>ID Réservation</th>
                  <th>Utilisateur (Email)</th>
                  <th>Nom Contact</th>
                  <th>Destination</th>
                  <th>Type Bus</th>
                  <th>Dates (Départ - Retour)</th>
                  <th>Places</th>
                  <th>Statut</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((booking) => (
                  <tr key={booking._id} className={`status-${booking.status}`}>
                    <td>{booking._id}</td>
                    <td>{booking.email}</td> {/* Assuming booking.email is the contact email from form */}
                    <td>{booking.nomComplet}</td>
                    <td>{booking.destination}</td>
                    <td>{booking.typeDuBus}</td>
                    <td>
                      {new Date(booking.dateDepart).toLocaleString()} - <br />
                      {new Date(booking.dateRetour).toLocaleString()}
                    </td>
                    <td>{booking.nbPlaces}</td>
                    <td>
                      <span className={`status-badge status-${booking.status}`}>{booking.status}</span>
                    </td>
                    <td className="actions-cell">
                      {booking.status === "pending" && (
                        <div className="action-group-inline">
                          <input
                            type="number"
                            placeholder="Prix"
                            value={bookingPrices[booking._id] || ""}
                            onChange={(e) => handlePriceChange(booking._id, e.target.value)}
                            className="price-input"
                          />
                          <button onClick={() => handleApproveBooking(booking._id)} className="action-button approve">
                            Approuver
                          </button>
                          <button onClick={() => handleRejectBooking(booking._id)} className="action-button reject">
                            Rejeter
                          </button>
                        </div>
                      )}
                      {booking.status === "approved" && (
                        <p>Prix: {booking.prix || "N/A"} €</p> /* Display price if approved */
                      )}
                      <button onClick={() => handleDeleteBooking(booking._id)} className="action-button delete">
                        Supprimer
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="dashboard-section">
        <h3>Toutes les Offres Utilisateurs</h3>
        {offers.length === 0 ? (
          <p className="empty-state">Aucune offre trouvée.</p>
        ) : (
          <div className="table-responsive">
            <table className="dashboard-table">
              <thead>
                <tr>
                  <th>ID Offre</th>
                  <th>Utilisateur (ID)</th> {/* Assuming offer has userId */}
                  <th>Prix Offert</th>
                  <th>Statut</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {offers.map((offer) => (
                  <tr key={offer._id} className={`status-${offer.status?.toLowerCase()}`}>
                    <td>{offer._id}</td>
                    <td>{offer.userId?.email || 'N/A'}</td>
                    <td>{offer.prix ? `${offer.prix} €` : "N/A"}</td>
                    <td>
                      <span className={`status-badge status-${offer.status?.toLowerCase()}`}>{offer.status}</span>
                    </td>
                    <td className="actions-cell">
                      <button onClick={() => handleDeleteOffer(offer._id)} className="action-button delete">
                        Supprimer
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}

export default AdminDashboard
