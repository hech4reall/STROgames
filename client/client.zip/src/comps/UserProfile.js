"use client"

import { useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { getUserOffers, clearError, acceptUserOffer, rejectUserOffer } from "../redux/slices/authSlice" // Corrected path
import "./UserProfile.css"

const UserProfile = () => {
  const dispatch = useDispatch()
  const { user, userOffers, loading, error, isAuthenticated } = useSelector((state) => state.auth)

  useEffect(() => {
    if (isAuthenticated && user && user._id) {
      dispatch(getUserOffers(user._id))
    }
    return () => {
      dispatch(clearError()) // Clear errors on unmount
    }
  }, [user, dispatch, isAuthenticated]);

  const AcceptOffer = (offerId) => {
    dispatch(acceptUserOffer(offerId));
  }
  const RejectOffer = (offerId) => {
    dispatch(rejectUserOffer(offerId));
  }

  if (!isAuthenticated) {
    return <div className="info-message">Veuillez vous connecter pour voir votre profil.</div>
  }

  if (loading && !userOffers.length) {
    return <div className="loading-message">Chargement de vos offres...</div>
  }

  if (error) {
    return <div className="error-message profile-error">Erreur: {error}</div>
  }

  return (
    <div className="user-profile-container">
      <header className="profile-header">
        <h2>Bienvenue, {user?.email}!</h2>
        <p>Consultez le statut de vos offres ici.</p>
      </header>

      <section className="offers-section">
        <h3>Vos Offres Envoyées</h3>
        {userOffers.length === 0 ? (
          <p className="empty-state-profile">Vous n'avez envoyé aucune offre pour le moment.</p>
        ) : (
          <ul className="offer-list-profile">
            {userOffers.map((offer) => (
              <li key={offer._id} className={`offer-item-profile status-${offer.status?.toLowerCase()}`}>
                <div className="offer-details">
                <p><strong>Destination:</strong> {offer.booking?.destination || 'N/A'}</p>
                <p><strong>Dates:</strong> {offer.booking?.dateDepart} - {offer.booking?.dateRetour}</p>
                  <p>
                    <strong>ID de l'offre :</strong> {offer._id}
                  </p>
                  <p>
                    <strong>Prix offert :</strong> {offer.prix ? `${offer.prix} €` : "N/A"}
                  </p>
                  <p>
                    <strong>Statut :</strong>{" "}
                    <span className={`status-badge-profile status-${offer.status?.toLowerCase()}`}>{offer.status}</span>
                  </p>
                </div>
                <div>
                    <button onClick={() => AcceptOffer(offer._id)}>
                        Accept
                    </button>
                    <button onClick={() => RejectOffer(offer._id)}>
                        Reject
                    </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}

export default UserProfile
