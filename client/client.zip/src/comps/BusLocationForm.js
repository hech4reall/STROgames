import { useState, useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom"
import { createBusBooking, clearBusError, clearBusSuccess } from "../redux/slices/busSlice" // Corrected path
import "./stylesp.css"

function BusLocationForm() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { user, isAuthenticated } = useSelector((state) => state.auth)
  const { loading, error, successMessage } = useSelector((state) => state.bus)

  const [formData, setFormData] = useState({
    nomComplet: "", // Changed from nom to nomComplet to match schema
    email: "", // Email for the booking, can be different from user's email
    telephone: "",
    destination: "",
    typeDuBus: "",
    dateDepart: "",
    dateRetour: "",
    nbPlaces: "1",
  })

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login")
    }
    // Clear errors/success messages on component mount or when user changes
    dispatch(clearBusError())
    dispatch(clearBusSuccess())
  }, [isAuthenticated, navigate, dispatch])

  useEffect(() => {
    if (successMessage) {
      alert("Location de bus demandée avec succès ! Votre demande est en attente de validation.")
      dispatch(clearBusSuccess()) // Clear message after showing
      navigate("/acceuil") // Or to a confirmation/dashboard page
    }
  }, [successMessage, dispatch, navigate])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!user || !user._id) {
      alert("Utilisateur non identifié. Veuillez vous reconnecter.")
      return
    }

    const bookingData = {
      ...formData,
      userId: user._id, // Add logged-in user's ID
      // The email in formData is the contact email for the booking, not necessarily user.email
      nbPlaces: Number.parseInt(formData.nbPlaces, 10), // Ensure nbPlaces is a number
    }
    dispatch(createBusBooking(bookingData))
  }

  return (
    <div className="form-container">
      <div className="form-logo-header">
        <span className="logo-text-form">SOTREGAMES</span>
        <h2>Formulaire de Location de Bus</h2>
      </div>
      <form className="bus-location-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="nomComplet">Nom complet du responsable :</label>
          <input
            type="text"
            id="nomComplet"
            name="nomComplet"
            value={formData.nomComplet}
            onChange={handleChange}
            required
            placeholder="Jean Dupont"
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email de contact :</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            placeholder="contact@exemple.com"
          />
        </div>
        <div className="form-group">
          <label htmlFor="telephone">Téléphone :</label>
          <input
            type="tel"
            id="telephone"
            name="telephone"
            value={formData.telephone}
            onChange={handleChange}
            required
            placeholder="0612345678"
          />
        </div>
        <div className="form-group">
          <label htmlFor="destination">Destination :</label>
          <select id="destination" name="destination" value={formData.destination} onChange={handleChange} required>
            <option value="">Choisissez une destination</option>
            <option value="Sfax">Sfax</option>
            <option value="Mednine">Mednine</option>
            <option value="Djerba">Djerba</option>
            <option value="Touzeur">Touzeur</option>
            <option value="Autre">Autre (à préciser)</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="typeDuBus">Type du bus :</label>
          <select id="typeDuBus" name="typeDuBus" value={formData.typeDuBus} onChange={handleChange} required>
            <option value="">Choisissez le type du bus</option>
            <option value="comfort">Mini Bus (Confort)</option>
            <option value="simple">Bus Normal (Simple)</option>
          </select>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="dateDepart">Date et heure de départ :</label>
            <input
              type="datetime-local"
              id="dateDepart"
              name="dateDepart"
              value={formData.dateDepart}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="dateRetour">Date et heure de retour :</label>
            <input
              type="datetime-local"
              id="dateRetour"
              name="dateRetour"
              value={formData.dateRetour}
              onChange={handleChange}
              required
            />
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="nbPlaces">Nombre de places souhaitées :</label>
          <input
            type="number"
            id="nbPlaces"
            name="nbPlaces"
            min="1"
            max="50"
            value={formData.nbPlaces}
            onChange={handleChange}
            required
          />
        </div>

        {error && <div className="error-message form-error">{error}</div>}

        <button type="submit" className="submit-button" disabled={loading}>
          {loading ? "Envoi en cours..." : "Demander la location"}
        </button>
      </form>
    </div>
  )
}

export default BusLocationForm
